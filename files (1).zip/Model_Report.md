# Predictive Modeling Report
## Wine Cultivar Classification

**Author:** [Your Name]
**Date:** June 2026

---

## 1. Introduction

This report documents a supervised machine learning project to predict wine cultivar (one of three classes) from 13 chemical measurements, using the UCI Wine Recognition Dataset. Three algorithms — Logistic Regression, Decision Tree, and Random Forest — were trained, evaluated, and compared, building on insights from a prior exploratory data analysis (EDA) of the same dataset.

## 2. Problem Statement

**Task:** Multiclass classification — predict which of three cultivars (class_0, class_1, class_2) a wine sample belongs to, based solely on its chemical profile.

**Why this matters:** In a real-world setting, chemical analysis is far cheaper and faster than manual cultivar identification by a sommelier or agricultural expert. A reliable classifier could automate quality control or origin verification in wine production.

## 3. Data Preparation

- **Train/test split:** 75% train (133 samples) / 25% test (45 samples), stratified to preserve class proportions.
- **Feature scaling:** All 13 features were standardized (zero mean, unit variance) using `StandardScaler`, fit on the training set only and applied to both sets. This step is essential for Logistic Regression (a distance/coefficient-based model) but does not affect tree-based models.
- **No missing values or duplicates** were present (confirmed during the earlier EDA phase), so no imputation or deduplication was needed.

## 4. Models Trained

| Model | Key Hyperparameters | Rationale |
|---|---|---|
| Logistic Regression | `max_iter=2000` | Simple, interpretable linear baseline |
| Decision Tree | `max_depth=4` | Non-linear; depth capped to reduce overfitting risk |
| Random Forest | `n_estimators=200`, `max_depth=6` | Ensemble method; typically more robust than a single tree |

## 5. Evaluation Methodology

Each model was evaluated using:
- **Test-set accuracy, macro-averaged precision, recall, and F1-score** (macro-averaging treats all three classes equally, regardless of class size)
- **5-fold cross-validation accuracy** on the training set, to estimate generalization more reliably than a single train/test split
- **Confusion matrices** to inspect exactly which classes were confused
- **Multiclass ROC curves** (one-vs-rest) with AUC per class

## 6. Results

### 6.1 Performance Summary

| Model | Test Accuracy | Precision (macro) | Recall (macro) | F1 (macro) | 5-fold CV Accuracy |
|---|---|---|---|---|---|
| Logistic Regression | 1.000 | 1.000 | 1.000 | 1.000 | 0.977 (±0.019) |
| Decision Tree | 0.956 | 0.967 | 0.950 | 0.956 | 0.895 (±0.076) |
| Random Forest | 1.000 | 1.000 | 1.000 | 1.000 | 0.970 (±0.015) |

### 6.2 Confusion Matrices

Both Logistic Regression and Random Forest produced **zero misclassifications** on the test set. The Decision Tree misclassified 2 of 45 test samples — one `class_0` sample predicted as `class_1`, and one `class_2` sample predicted as `class_1`. No errors were severe (no class was confused with a "distant" class), suggesting the tree's boundary is only slightly off rather than fundamentally wrong.

### 6.3 ROC Curves & AUC

- Logistic Regression and Random Forest: AUC = 1.000 for all three classes.
- Decision Tree: AUC ranged from 0.958–0.967 across classes — still strong, but visibly lower and less smooth (a step-function shape typical of single decision trees, which produce discrete probability outputs at each leaf).

### 6.4 Feature Importance

Both tree-based models agree that the most predictive features are:
1. **flavanoids**
2. **color_intensity**
3. **proline**

Random Forest additionally distributes meaningful importance to `alcohol`, `hue`, and `od280/od315_of_diluted_wines`, since it averages over 200 trees built on different feature/sample subsets — giving a more nuanced and stable importance ranking than a single Decision Tree, which relies almost entirely on its top 2–3 splitting features.

These findings **directly corroborate the prior EDA**, which identified flavanoids, color intensity, proline, alcohol, and OD280/OD315 as the chemical properties showing the clearest separation across wine classes.

## 7. Discussion

- **Why do Logistic Regression and Random Forest tie at 1.000 test accuracy?** The wine dataset's three classes are well-separated in feature space (confirmed visually in the EDA pairplots), so even a linear decision boundary suffices. This is not always the case in real-world datasets, where ensemble or non-linear methods typically outperform linear models by a wider margin.
- **Why trust cross-validation over the single test-set score?** With only 45 test samples, a single split can show artificially perfect or artificially poor results due to chance. The 5-fold CV accuracy — averaged across 5 different train/validation splits — gives a more dependable estimate: Random Forest (0.970 ± 0.015) is both high-performing and the most *stable* (lowest variance) of the three models.
- **Is the Decision Tree's lower score a problem?** Not necessarily — a single decision tree is inherently higher-variance than an ensemble. Its lower, more variable CV score (0.895 ± 0.076) is expected behavior, not evidence of a coding error.

## 8. Conclusion

All three models perform well on this classic, well-separated dataset, but **Random Forest offers the best balance of accuracy and stability** when judged by cross-validation rather than a single test split. Logistic Regression remains an excellent choice when model interpretability is a priority, since its coefficients directly indicate each feature's linear contribution to each class.

## 9. Next Steps

- **Hyperparameter tuning:** Use `GridSearchCV` or `RandomizedSearchCV` to tune `max_depth`, `n_estimators`, and `min_samples_split` for the tree-based models.
- **Try additional algorithms:** k-Nearest Neighbors, Support Vector Machine, or Gradient Boosting (e.g., XGBoost) for further comparison.
- **External validation:** Test the saved model on wine samples from a different region/vintage, if available, to confirm the model generalizes beyond this specific dataset rather than exploiting dataset-specific quirks.
- **Deployment:** Wrap the saved `best_model.joblib` and `scaler.joblib` in a simple API (e.g., Flask/FastAPI) to serve predictions on new chemical measurements.
