# 🍷 Predictive Modeling: Wine Cultivar Classification

A complete supervised machine learning project that predicts wine cultivar from chemical measurements, comparing **Logistic Regression**, **Decision Tree**, and **Random Forest** classifiers — with full model evaluation, confusion matrices, and multiclass ROC curves.

## 📌 Project Overview

| | |
|---|---|
| **Objective** | Predict wine cultivar (1 of 3 classes) from 13 chemical features |
| **Dataset** | [UCI Wine Recognition Dataset](https://archive.ics.uci.edu/ml/datasets/Wine) (178 samples, 13 features, 3 classes) |
| **Algorithms** | Logistic Regression, Decision Tree, Random Forest |
| **Tools** | Python, Pandas, Scikit-learn, Matplotlib, Seaborn |
| **Deliverables** | Jupyter Notebook, training script, saved model, evaluation charts, written report |

## 🎯 Key Features of This Project

- **Train/test split with stratification** and feature standardization
- **Three supervised learning algorithms** trained and compared head-to-head
- **5-fold cross-validation** for a robust generalization estimate (not just a single train/test split)
- **Confusion matrices** for all three models, side-by-side
- **Multiclass ROC curves** (one-vs-rest) with AUC scores per class
- **Feature importance** comparison between Decision Tree and Random Forest
- **Best model auto-selected and saved** as a reusable `.joblib` artifact

## 📂 Repository Structure

```
wine-predictive-modeling/
├── data/
│   └── wine_dataset.csv                  # UCI Wine Recognition Dataset
├── notebooks/
│   └── Predictive_Modeling_Wine.ipynb    # Full executed analysis & modeling notebook
├── src/
│   └── predictive_modeling.py            # Standalone script — trains, evaluates, saves model
├── models/
│   ├── best_model.joblib                 # Best-performing trained model
│   └── scaler.joblib                     # Fitted StandardScaler (needed for Logistic Regression)
├── images/
│   ├── 01_confusion_matrices.png
│   ├── 02_roc_curves.png
│   ├── 03_model_comparison.png
│   └── 04_feature_importance.png
├── reports/
│   ├── Model_Report.md                   # Structured written report of findings
│   ├── model_comparison.csv
│   ├── classification_reports.txt
│   └── results_summary.json
├── requirements.txt
├── LICENSE
└── README.md
```

## 🚀 How to Run

1. **Clone the repo**
   ```bash
   git clone https://github.com/<your-username>/wine-predictive-modeling.git
   cd wine-predictive-modeling
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the analysis**

   Option A — Jupyter Notebook (recommended, full narrative + visuals):
   ```bash
   jupyter notebook notebooks/Predictive_Modeling_Wine.ipynb
   ```

   Option B — Standalone script (retrains models, regenerates all charts/reports/saved model):
   ```bash
   python src/predictive_modeling.py
   ```

4. **Reuse the saved model** for new predictions:
   ```python
   import joblib
   model = joblib.load("models/best_model.joblib")
   scaler = joblib.load("models/scaler.joblib")
   # If using Logistic Regression, remember to scale new input features first:
   # X_new_scaled = scaler.transform(X_new)
   # model.predict(X_new_scaled)
   ```

## 📊 Results Summary

| Model | Test Accuracy | Precision (macro) | Recall (macro) | F1 (macro) | 5-fold CV Accuracy |
|---|---|---|---|---|---|
| Logistic Regression | 1.000 | 1.000 | 1.000 | 1.000 | 0.977 (±0.019) |
| Decision Tree | 0.956 | 0.967 | 0.950 | 0.956 | 0.895 (±0.076) |
| Random Forest | 1.000 | 1.000 | 1.000 | 1.000 | 0.970 (±0.015) |

**Best model selected: Logistic Regression** (tied with Random Forest on test accuracy; chosen here for simplicity and interpretability — see [`reports/Model_Report.md`](reports/Model_Report.md) for the full discussion of why Random Forest may be preferable in production).

## 🖼️ Sample Visualizations

**Confusion Matrices**

![Confusion Matrices](images/01_confusion_matrices.png)

**ROC Curves**

![ROC Curves](images/02_roc_curves.png)

## 🔍 Key Insights

1. **Logistic Regression and Random Forest** both achieve perfect test accuracy, with Random Forest showing the most stable cross-validation performance (lowest standard deviation).
2. **Decision Tree** underperforms slightly relative to the ensemble method — a single tree is more prone to variance on this small dataset (178 samples total).
3. **Most predictive features:** `flavanoids`, `color_intensity`, and `proline` consistently rank highest in both tree-based models' feature importances — directly matching the strongest correlations found in the companion EDA project.
4. **Cross-validation matters:** the single train/test split shows perfect scores for two models, but 5-fold CV reveals more realistic, slightly lower accuracy — a reminder to never trust a single split alone.

See [`reports/Model_Report.md`](reports/Model_Report.md) for the complete write-up.

## 🧠 Skills Demonstrated

- Supervised learning workflow: train/test split, scaling, model fitting, evaluation
- Comparing linear vs. tree-based vs. ensemble algorithms
- Cross-validation for robust performance estimation
- Multiclass classification metrics: precision, recall, F1, confusion matrix, ROC/AUC
- Model interpretability via feature importance
- Saving and reloading trained models for reuse (`joblib`)

## 📄 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

## 🙏 Acknowledgments

Dataset originally created by Forina, M. et al., PARVUS — sourced via the [UCI Machine Learning Repository](https://archive.ics.uci.edu/ml/datasets/Wine) and distributed through `scikit-learn.datasets.load_wine`.
